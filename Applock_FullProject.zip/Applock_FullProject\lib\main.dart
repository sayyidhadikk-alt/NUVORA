import 'package:flutter/material.dart';
import 'src/parent_wizard.dart';

void main() {
  runApp(const AppLockApp());
}

class AppLockApp extends StatelessWidget {
  const AppLockApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'App Lock',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const ParentWizard(),
    );
  }
}
